from PIL import Image
#کل این برنامه رو پارسا عدل پرور کدش رو زده
# توقع داشتم این کار تو یه ساعت و نیم تموم بشه که از ساعت 5:50 نشستم پای کامپیوتر و تا 7:10 طول کشید و تایم خوبی بود
def GrayScale(img):
    #پنج خط بعدی چک میکنن که هر پیکسل 4 تا متغیر داره یا 5 تا
    #اگه فلگمون یک بود یعنی 3 تا متغیر داره اگه صفر بود یعنی 4 تا
    flag = 1
    try:
        r, g, b = img.getpixel((x, y))
    except:
        flag = 0
    # اینجا به بعد میاد خاکستری میکنه عکسو
    # میانگین میگیره از سه تا رنگ هر پیکسل و جای همشون میذاره
    ximg = img.size[0]
    yimg = img.size[1]
    for x in range(ximg):
        for y in range(yimg):
            if flag == 1:
                r, g, b = img.getpixel((x, y))
                m = (r + g + b) // 3
                img.putpixel((x, y), (m, m, m))
            else:
                r, g, b, a = img.getpixel((x, y))
                m = (r + g + b) // 3
                img.putpixel((x, y), (m, m, m, a))
    return img
#-------------------------------------------------------------------------------------
def BlackAndWhite(img):
    #پنج خط بعدی چک میکنن که هر پیکسل 4 تا متغیر داره یا 5 تا
    #اگه فلگمون یک بود یعنی 3 تا متغیر داره اگه صفر بود یعنی 4 تا
    flag = 1
    try:
        r, g, b = img.getpixel((x, y))
    except:
        flag = 0
    # اینجا به بعد میاد سیاه سفید میکنه عکسو
    # اگه از 127 بیشتر باشه میانگین سه تا عدد هر پیکسل، میاد هر سه تارو 255 میکنه
    # اگه کمتر باشه هر سه تارو صفر میکنه
    ximg = img.size[0]
    yimg = img.size[1]
    for x in range(ximg):
        for y in range(yimg):
            if flag == 1:
                r, g, b = img.getpixel((x, y))
                m = (r + g + b) // 3
                if m < 127:
                    m = 0
                else:
                    m = 255
                img.putpixel((x, y), (m, m, m))
            else:
                r, g, b, a = img.getpixel((x, y))
                m = (r + g + b) // 3
                if m < 127:
                    m = 0
                else:
                    m = 255
                img.putpixel((x, y), (m, m, m, a))
    return img
#-------------------------------------------------------------------------------------
def Negative(img):
    #پنج خط بعدی چک میکنن که هر پیکسل 4 تا متغیر داره یا 5 تا
    #اگه فلگمون یک بود یعنی 3 تا متغیر داره اگه صفر بود یعنی 4 تا
    flag = 1
    try:
        r, g, b = img.getpixel((x, y))
    except:
        flag = 0
    # میاد 255 رو از هر عدد کم میکنه(منظور از عدد، سه عدد داخل هر پیکسله)
    ximg = img.size[0]
    yimg = img.size[1]
    for x in range(ximg):
        for y in range(yimg):
            if flag == 1:
                r, g, b = img.getpixel((x, y))
                img.putpixel((x, y), (255 - r, 255 - g, 255 - b))
            else:
                r, g, b, a = img.getpixel((x, y))
                img.putpixel((x, y), (255 - r, 255 - g, 255 - b, a))
    return img
#-------------------------------------------------------------------------------------
def rotate_right_90(img):
    rotated_img = img.rotate(-90)
    return rotated_img
#---------------------------------------------
def rotate_right_180(img):
    rotated_img = img.rotate(-180)
    return rotated_img
#---------------------------------------------
def rotate_right_270(img):
    rotated_img = img.rotate(-270)
    return rotated_img
#-------------------------------------------------------------------------------------
def rotate_left_90(img):
    rotated_img = img.rotate(90)
    return rotated_img
#---------------------------------------------
def rotate_left_180(img):
    rotated_img = img.rotate(180)
    return rotated_img
#---------------------------------------------
def rotate_left_270(img):
    rotated_img = img.rotate(270)
    return rotated_img
#-------------------------------------------------------------------------------------
def Resize(img, length, Height):
    resized_img = img.resize((length,Height))
    return resized_img
#-------------------------------------------------------------------------------------
def red_increase(img):
    #پنج خط بعدی چک میکنن که هر پیکسل 4 تا متغیر داره یا 5 تا
    #اگه فلگمون یک بود یعنی 3 تا متغیر داره اگه صفر بود یعنی 4 تا
    flag = 1
    try:
        r, g, b = img.getpixel((x, y))
    except:
        flag = 0
    #اینجا میاد میزان رنگ قرمز پیکسل رو دو برابر میکنه
    ximg = img.size[0]
    yimg = img.size[1]
    for x in range(ximg):
        for y in range(yimg):
            r, g, b = img.getpixel((x, y))
            if r * 2 <= 255:
                r *= 2
            else:
                r = 255
            img.putpixel((x, y), (r,g,b))
    return img
#-------------------------------------------------------------------------------------
def green_increase(img):
    #پنج خط بعدی چک میکنن که هر پیکسل 4 تا متغیر داره یا 5 تا
    #اگه فلگمون یک بود یعنی 3 تا متغیر داره اگه صفر بود یعنی 4 تا
    flag = 1
    try:
        r, g, b = img.getpixel((x, y))
    except:
        flag = 0
    #اینجا میاد میزان رنگ سبز پیکسل رو دو برابر میکنه
    ximg = img.size[0]
    yimg = img.size[1]
    for x in range(ximg):
        for y in range(yimg):
            r, g, b = img.getpixel((x, y))
            if g * 2 <= 255:
                g *= 2
            else:
                g = 255
            img.putpixel((x, y), (r,g,b))
    return img
#-------------------------------------------------------------------------------------
def blue_increase(img):
    #پنج خط بعدی چک میکنن که هر پیکسل 4 تا متغیر داره یا 5 تا
    #اگه فلگمون یک بود یعنی 3 تا متغیر داره اگه صفر بود یعنی 4 تا
    flag = 1
    try:
        r, g, b = img.getpixel((x, y))
    except:
        flag = 0
    #اینجا میاد میزان رنگ آبی پیکسل رو دو برابر میکنه
    ximg = img.size[0]
    yimg = img.size[1]
    for x in range(ximg):
        for y in range(yimg):
            r, g, b = img.getpixel((x, y))
            if b * 2 <= 255:
                b *= 2
            else:
                b = 255
            img.putpixel((x, y), (r,g,b))
    return img