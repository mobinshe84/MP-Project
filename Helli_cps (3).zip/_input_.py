
import settings
from PIL import Image
# مبین نوشته -----------------------------------------
# و اگر کلمه ای شبیه به آنها باشد را به کاربر می گوییم که آیا مقصودت اینه یا نه
def incorrect(ent,wrd):
    if len(ent) <= len(wrd)+1 and len(ent) >= len(wrd)-1:
        seem = 0
        for i in ent:
            for j in wrd:
                if i == j:
                    seem += 1
        if seem >= 3:
            print('Did you mean: {x}?  (y/n)'.format(x = wrd))
            ans = input()
            if ans == 'n':
                return False
            return True

# اول کار این برنامه رو مبین کامل کرد
# بعدش پارسا اومد بعضی از اسم هارو که گفته بودین خوب نیست رو درست کرد و همچنین یه سری چیزا اضافه کرد
# مثل اینکه وقتی هلپ رو میزنیم بعد اینکه کاراشو انجام دادیم دوباره برنامه ورودی بخواد و ورودی اصلی رو بگیره
# همون آدرس عکس و دستور و این ها
# همچنین متن help رو پارسا عدل پرور نوشته
def Special_input():
    user_input = input("Write 'Help' command if you confused :)\nWRITE A STATE: ")
    input_list = list(user_input.split())
    input_flag = False
    Help_flag = False
    if len(input_list) < 3:
        Help_flag = True
        input_flag = False
        
    while Help_flag:
        if user_input == 'Help':
            print()
            for i in settings.HELP:
                print(i)
            user_input = input("Print your problem: (Between 1,2,3): ")

            if user_input == '1':
                print(settings.INS_HELP[0])
                Help_flag = False
                input_flag = True
                print(12)

            elif user_input == '2':
                print(settings.INS_HELP[1])
                Help_flag = False
                input_flag = True

            elif user_input == '3':
                print(settings.INS_HELP[2])
                Help_flag = False
                input_flag = True

            else:
                print(settings.ERROR[0])
                Help_flag = False
                return False
            
        else:
            Help_flag = incorrect(user_input, 'Help')
            if Help_flag:
                user_input = 'Help'
    if input_flag:
        user_input = input('Now write your command:')
        input_list = list(user_input.split())

    len_inp_list = len(input_list)

    if len_inp_list < 4:
        print(settings.ERROR[0])
        return False

    for test in range(len_inp_list):
        # در این فور، برنامه چک میکند که اعضای لیست، صحیح باشند
        
        if test == 0:
            # اولین خانه و آخرین خانه لیست باید محل ذخیره تصویر ورودی و محل ذخیره تصویر خروجی باشد
            # در اینجا چک میکنیم که آیا این دو آدرس صحیح هستند یا نه
            # اگر نبود، تابع ارور میدهد و به برنامه main باز میگردد
            try:
                print(input_list[test])
                a = Image.open(input_list[test])
            except:
                print(input_list[test] + ' ' + settings.ERROR[1])
                return False

        if test != 0 and test != len_inp_list - 1:
            # بقیه اعضای لیست باید دستور باشند مانند edit یا Grayscale
            # در اینجا چک میکنیم که این اعضا حتما جزء دستورات باشند.
            # و اگر کلمه ای شبیه به آنها باشد را به کاربر می گوییم که آیا مقصودت اینه یا نه
            if not input_list[test] in settings.MENUS_VALID_STATES:
                
                if incorrect(input_list[test],'edit') == False:
                    print(input_list[test] + ' is invalid!')
                    return False
                

                elif not input_list[test] in settings.EDIT:
                    for i in settings.ERROR:
                        if incorrect(input_list[test],i) == False:
                            print(input_list[test] + ' is invalid. try again ...')
                            return False
                        else:
                            input_list[test] = i
                    

    print("Ongoing operation...")
    return input_list
