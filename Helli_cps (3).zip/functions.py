import settings
import effects.color_effect
from PIL import Image

def main_menu():
    answers = ['1','2','3','4']
    state = 'main_menu'
    while state == 'main_menu':
        print (settings.MAIN_MENU)
        entrance = input()

        if entrance in answers:
            if entrance == '1':
                state = 'insert'
            elif entrance == '2':
                state = 'export'
            elif entrance == '3':
                state = 'edit'
            elif entrance == '4':
                state = 'exit'
        else:
            state_error()

    return state
            
def insert_menu(_image_):
    
    Address = _image_

    try:
        IMG = Image.open(Address)
    except:
        print (settings.ERROR[2])

    print ()
    print ('successfuly has been found')

    return IMG

def export_menu(IMG, Address):
    print ('exporting to ' + Address + ' ...')
    IMG.save(Address)
    print ('File has been exported!')

def edit_menu(IMG, Entrance):
    if Entrance == 'Grayscale':
        IMG = effects.color_effect.GrayScale(IMG)

        
    elif Entrance == 'WhiteAndBlack':
        IMG = effects.color_effect.BlackAndWhite(IMG)


    elif Entrance == 'Negative':
        IMG = effects.color_effect.Negative(IMG)

        

    print ('successfuly has been edited')

    return IMG

def exit_menu():
    return 'True'

def state_error():
    print ('Error: Invalid Input, try again ...')