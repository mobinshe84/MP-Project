#هردو نزدیک یه ساعت و نیم تو ویس بودیم که کار اصلی رو انجام دادیم (گذاشتن هلپ رو برنامه و رفع یه سری باگ ها)
#و تا نیم ساعت بعدش هم پارسا عدل پرور داشت رو برنامه یخورده تغییر ایجاد میکرد (که تو _input_ گفتیم)
#و همچنین طرح جدید رو مکتوب میکرد
# در کل حدود دو ساعت زمان برد که تخمینمون هم همین حدود بود

import settings
import functions
import _input_

Address = ''
IMG = ''


input_list = _input_.Special_input()

if input_list != False:
    IMG = functions.insert_menu(input_list[0])
    IMG = functions.edit_menu(IMG, input_list[2])
    functions.export_menu(IMG, input_list[3])

    print ('Process has been done :)')



