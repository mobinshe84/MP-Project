# State
MENUS_VALID_STATES = [
    "edit"
]

# Menus
MAIN_MENU = """
Please Choose:
1. Insert New pic
2. Export New File
3. Edit
4. Exit
"""
HELP = [
    "What do you want?",
    "1.How to write an address:",
    "2.Effect's lists",
    "3.Errors"
]
INS_HELP = [
    """
    How to master the program:
    Type Your photo address, then type "edit" and type the effect you want. At the end, write the address of the output file and do the following:
    Example:
    example.jpg edit Grayscale example2.jpg""",
    
    
    """
    Effect Command:
    BlackAndWhite					Black and white photo
    Grayscale					    Gray photos
    Negative					    Negative photo
    rotate_right_90					Rotate the image 90 degrees to the right
    rotate_right_180				Rotate the image 180 degrees to the right
    rotate_right_270				Rotate the image 270 degrees to the right
    rotate_left_90					Rotate the image 90 degrees to the right
    rotate_left_180					Rotate the image 180 degrees to the left
    rotate_left_270					Rotate the image 270 degrees to the left
    red_increase					Doubles the red color of the image
    blue_increase					Doubles the blue color of the image
    green_increase					Doubles the green color of the image""",
    
    
    """
    Errors:
    Error: invalid input                    		You entered the invalid input!
    Error: Address is not correct			        The address you entered is incorrect!
    Error: There is no pic				            There is no image in your address!"""

]
INSERT = """
    تکمیل کنید
"""
EXPORT = """
    تکمیل کنید
"""
EDIT = [
    "Grayscale",
    "WhiteAndBlack",
    "Negative",
    "rotate_right_90",
    "rotate_right_180",
    "rotate_right_270",
    "rotate_left_90",
    "rotate_left_180",
    "rotate_left_270",
    "Resize",
    "red_increase",
    "green_increase",
    "blue_increase"
]
ERROR = [
    "invalid input",
    "Address is not correct",
    "There is no pic"
]